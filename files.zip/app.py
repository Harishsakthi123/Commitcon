"""
Mini Game Hub - Flask Backend
==============================
This is the main application file. It handles:
- Serving HTML pages for the dashboard and each game
- REST API endpoints for saving game results and reading statistics
- SQLite database setup and access

Run with: python app.py
"""

from flask import Flask, render_template, request, jsonify, g
import sqlite3
import os
from datetime import datetime

app = Flask(__name__)

# Path to our SQLite database file (created automatically on first run)
DATABASE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "database.db")

# List of games we support. Used for validation and for the stats page.
VALID_GAMES = ["Rock Paper Scissors", "Number Guessing", "Tic-Tac-Toe", "Quick Quiz"]


# ---------------------------------------------------------------------------
# Database helpers
# ---------------------------------------------------------------------------

def get_db():
    """
    Return a database connection for the current request.
    Flask's 'g' object keeps one connection per request, so we don't
    open a new connection every time we need one.
    """
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row  # lets us access columns by name
    return g.db


@app.teardown_appcontext
def close_db(exception=None):
    """Automatically close the database connection when the request ends."""
    db = g.pop("db", None)
    if db is not None:
        db.close()


def init_db():
    """
    Create the game_results table if it does not already exist.
    This runs automatically every time the app starts, so the database
    is always ready - no manual setup needed.
    """
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute(
        """
        CREATE TABLE IF NOT EXISTS game_results (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            player_name TEXT NOT NULL,
            game_name TEXT NOT NULL,
            score INTEGER NOT NULL,
            result TEXT,
            played_at TEXT NOT NULL
        )
        """
    )
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# Page routes (serve HTML templates)
# ---------------------------------------------------------------------------

@app.route("/")
def home():
    """Home dashboard with game cards and overall statistics."""
    return render_template("index.html")


@app.route("/rock-paper-scissors")
def rock_paper_scissors_page():
    return render_template("rps.html")


@app.route("/number-guessing")
def number_guessing_page():
    return render_template("guessing.html")


@app.route("/tic-tac-toe")
def tic_tac_toe_page():
    return render_template("tictactoe.html")


@app.route("/quick-quiz")
def quick_quiz_page():
    return render_template("quiz.html")


@app.route("/leaderboard")
def leaderboard_page():
    return render_template("leaderboard.html")


# ---------------------------------------------------------------------------
# API routes (JSON endpoints used by JavaScript on the front end)
# ---------------------------------------------------------------------------

@app.route("/api/save_result", methods=["POST"])
def save_result():
    """
    Save a single game result to the database.
    Expects JSON body:
        {
            "player_name": "Alice",
            "game_name": "Rock Paper Scissors",
            "score": 5,
            "result": "Win"
        }
    """
    data = request.get_json(silent=True) or {}

    # --- Basic input validation (keep it simple but safe) ---
    player_name = str(data.get("player_name", "")).strip()
    game_name = str(data.get("game_name", "")).strip()
    result = str(data.get("result", "")).strip()
    score_raw = data.get("score", 0)

    if not player_name:
        player_name = "Guest"          # fall back to a default name
    player_name = player_name[:30]     # avoid excessively long names

    if game_name not in VALID_GAMES:
        return jsonify({"success": False, "error": "Invalid game name"}), 400

    try:
        score = int(score_raw)
    except (ValueError, TypeError):
        return jsonify({"success": False, "error": "Score must be a number"}), 400

    if score < 0:
        score = 0

    played_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    db = get_db()
    db.execute(
        """
        INSERT INTO game_results (player_name, game_name, score, result, played_at)
        VALUES (?, ?, ?, ?, ?)
        """,
        (player_name, game_name, score, result, played_at),
    )
    db.commit()

    return jsonify({"success": True, "message": "Result saved successfully"})


@app.route("/api/stats", methods=["GET"])
def get_stats():
    """
    Return overall player statistics used on the home dashboard:
        - total games played (rows in the table)
        - best score overall
        - a breakdown of games played per game type
    Optional query param: ?player=NAME to filter stats for one player.
    """
    db = get_db()
    player = request.args.get("player", "").strip()

    if player:
        total_played = db.execute(
            "SELECT COUNT(*) AS count FROM game_results WHERE player_name = ?",
            (player,),
        ).fetchone()["count"]

        best_score_row = db.execute(
            "SELECT MAX(score) AS best FROM game_results WHERE player_name = ?",
            (player,),
        ).fetchone()
    else:
        total_played = db.execute("SELECT COUNT(*) AS count FROM game_results").fetchone()["count"]
        best_score_row = db.execute("SELECT MAX(score) AS best FROM game_results").fetchone()

    best_score = best_score_row["best"] if best_score_row["best"] is not None else 0

    return jsonify(
        {
            "success": True,
            "total_games": len(VALID_GAMES),
            "total_played": total_played,
            "best_score": best_score,
        }
    )


@app.route("/api/leaderboard", methods=["GET"])
def get_leaderboard():
    """
    Return the leaderboard: all results sorted by highest score first.
    Optional query param: ?game=Game Name to filter by a specific game.
    Includes a computed 'rank' field for each row.
    """
    db = get_db()
    game_filter = request.args.get("game", "").strip()

    if game_filter and game_filter != "All Games":
        rows = db.execute(
            """
            SELECT player_name, game_name, score, result, played_at
            FROM game_results
            WHERE game_name = ?
            ORDER BY score DESC, played_at ASC
            LIMIT 100
            """,
            (game_filter,),
        ).fetchall()
    else:
        rows = db.execute(
            """
            SELECT player_name, game_name, score, result, played_at
            FROM game_results
            ORDER BY score DESC, played_at ASC
            LIMIT 100
            """
        ).fetchall()

    leaderboard = []
    for index, row in enumerate(rows, start=1):
        leaderboard.append(
            {
                "rank": index,
                "player_name": row["player_name"],
                "game_name": row["game_name"],
                "score": row["score"],
                "result": row["result"],
                "played_at": row["played_at"],
            }
        )

    return jsonify({"success": True, "leaderboard": leaderboard})


@app.route("/api/quiz_questions", methods=["GET"])
def get_quiz_questions():
    """
    Return the 10 quiz questions as JSON.
    Kept on the backend so the frontend just fetches them (no external API).
    """
    questions = [
        {
            "question": "What is the capital of France?",
            "options": ["Berlin", "Madrid", "Paris", "Rome"],
            "answer": "Paris",
        },
        {
            "question": "Which planet is known as the Red Planet?",
            "options": ["Earth", "Mars", "Jupiter", "Venus"],
            "answer": "Mars",
        },
        {
            "question": "What is 8 x 7?",
            "options": ["54", "56", "58", "64"],
            "answer": "56",
        },
        {
            "question": "Who wrote 'Romeo and Juliet'?",
            "options": ["Charles Dickens", "William Shakespeare", "Mark Twain", "Jane Austen"],
            "answer": "William Shakespeare",
        },
        {
            "question": "What is the largest ocean on Earth?",
            "options": ["Atlantic", "Indian", "Arctic", "Pacific"],
            "answer": "Pacific",
        },
        {
            "question": "Which language is primarily used for styling web pages?",
            "options": ["HTML", "CSS", "Python", "SQL"],
            "answer": "CSS",
        },
        {
            "question": "How many continents are there on Earth?",
            "options": ["5", "6", "7", "8"],
            "answer": "7",
        },
        {
            "question": "What gas do plants absorb from the atmosphere?",
            "options": ["Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen"],
            "answer": "Carbon Dioxide",
        },
        {
            "question": "What is the chemical symbol for Gold?",
            "options": ["Ag", "Au", "Gd", "Go"],
            "answer": "Au",
        },
        {
            "question": "Which of these is NOT a programming language?",
            "options": ["Python", "Java", "Cobra", "Photoshop"],
            "answer": "Photoshop",
        },
    ]
    return jsonify({"success": True, "questions": questions})


# ---------------------------------------------------------------------------
# App entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    init_db()  # make sure the database + table exist before serving requests
    print("Mini Game Hub is running! Open http://127.0.0.1:5000 in your browser.")
    app.run(debug=True)
else:
    # Also initialize the DB if imported by a WSGI server (e.g. gunicorn)
    init_db()
